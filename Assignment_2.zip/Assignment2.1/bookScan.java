
/**
 * Write a description of class bookScan here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class bookScan
{
    private bookTemplate book;

    /**
     * Constructor for objects of class bookScan
     */
    public bookScan(bookTemplate book)
    {
        this.book = book;
    }

    public void printBookData()
    {
        System.out.println("Book Title: " + book.getBookTitle());
        System.out.println("Author Name: " + book.getAuthorFirstName() + " " + book.getAuthorLastName());
        System.out.println("ISBN Number: " + book.getISBNnumber());
        System.out.println("Publication Date: " + book.getPublicationDate());
        System.out.println("Number of Pages: " + book.getNumberOfPages());
    }
}
