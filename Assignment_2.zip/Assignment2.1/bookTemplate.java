
/**
 * Write a description of class bookTemplate here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class bookTemplate
{
    // instance variables - replace the example below with your own
    private String authorLastName;
    private String authorFirstName;
    private int ISBNnumber;
    private String bookTitle;
    private String publicationDate;
    private int numberOfPages;

    /**
     * Constructor for objects of class bookTemplate
     */
    public bookTemplate(String authorLastName, String authorFirstName, 
    int ISBNnumber, String bookTitle, String publicationDate, int numberOfPages)
    {
        this.authorLastName = authorLastName;
        this.authorFirstName = authorFirstName;
        this.ISBNnumber = ISBNnumber;
        this.bookTitle = bookTitle;
        this.publicationDate = publicationDate;
        this.numberOfPages = numberOfPages;
    }

    public String getAuthorLastName()
    {
        return authorLastName;
    }
  
    public void setAuthorLastName(String authorLastName) 
    {
        this.authorLastName = authorLastName;
    }
  
    public String getAuthorFirstName() 
    {
        return authorFirstName;
    }
  
    public void setAuthorFirstName(String authorFirstName) 
    {
        this.authorFirstName = authorFirstName;
    }
  
    public int getISBNnumber() 
    {
        return ISBNnumber;
    }
  
    public void setISBNnumber(int ISBNnumber) 
    {
        this.ISBNnumber = ISBNnumber;
    }
  
    public String getBookTitle() 
    {
        return bookTitle;
    }
  
    public void setBookTitle(String bookTitle) 
    {
        this.bookTitle = bookTitle;
    }
  
    public String getPublicationDate() 
    {
        return publicationDate;
    }
  
    public void setPublicationDate(String publicationDate) 
    {
        this.publicationDate = publicationDate;
    }
  
    public int getNumberOfPages() 
    {
        return numberOfPages;
    }
  
    public void setNumberOfPages(int numberOfPages) {
        if (numberOfPages < 10) {
            System.out.println("Error: Number of pages must be 10 or more.");
    }       else {
                this.numberOfPages = numberOfPages;
    }
  }
  
}

