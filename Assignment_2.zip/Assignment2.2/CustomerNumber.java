import java.util.Scanner;
 
/**
 * Write a description of class bookScan here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */

public class CustomerNumber 
{
 
    public static void main(String[] args) 
    {
        String lastName, firstName, companyName, address, city, state, zip;
        int phone;
        String designType;
        int basePrice, feature1, feature2, feature3, feature4, feature5;
        int customerNumber;

        Scanner input = new Scanner(System.in);
 
        System.out.print("Enter your last name: ");
        lastName = input.nextLine();
 
        System.out.print("Enter your first name: ");
        firstName = input.nextLine();
 
        System.out.print("Enter your company name: ");
        companyName = input.nextLine();
 
        System.out.print("Enter your address: ");
        address = input.nextLine();
 
        System.out.print("Enter your city: ");
        city = input.nextLine();
 
        System.out.print("Please enter your state: ");
        state = input.nextLine();
 
        System.out.print("Enter your zip code: ");
        zip = input.nextLine();
 
        System.out.print("Enter your phone number: ");
        phone = input.nextInt();
 
        System.out.println("Select a design type: ");
        System.out.println("[1] Nature");
        System.out.println("[2] Tech");
        System.out.println("[3] Business");
        System.out.println("[4] Music");
        System.out.println("[5] Naughty");
        designType = input.nextLine();
 
        if (designType.equals("1")) {
            basePrice = 300;
            feature1 = 10;
            feature2 = 15;
            feature3 = 20;
            feature4 = 25;
            feature5 = 30;
        } else if (designType.equals("2")) {
            basePrice = 350;
            feature1 = 20;
            feature2 = 30;
            feature3 = 40;
            feature4 = 50;
            feature5 = 60;
        } else if (designType.equals("3")) {
            basePrice = 375;
            feature1 = 30;
            feature2 = 40;
            feature3 = 50;
            feature4 = 60;
            feature5 = 70;
        } else if (designType.equals("4")) {
            basePrice = 400;
            feature1 = 85;
            feature2 = 95;
            feature3 = 110;
            feature4 = 130;
            feature5 = 210;
        } else {
            basePrice = 500;
            feature1 = 100;
            feature2 = 200;
            feature3 = 300;
            feature4 = 400;
            feature5 = 500;
        }
 
        customerNumber = (int) (Math.random() * 90000) + 10000;
 
        System.out.println("***********************");
        System.out.println("BILL OF SALE");
        System.out.println("***********************");
        System.out.println("Name: " + lastName + ", " + firstName);
        System.out.println("Company: " + companyName);
        System.out.println("Address: " + address + ", " + city + ", " + state + " " + zip);
        System.out.println("Phone: " + phone);
        System.out.println("Design Type: " + designType);
        System.out.println("Base Price: $" + basePrice);
        System.out.println("Feature 1: $" + feature1);
        System.out.println("Feature 2: $" + feature2);
        System.out.println("Feature 3: $" + feature3);
        System.out.println("Feature 4: $" + feature4);
        System.out.println("Feature 5: $" + feature5);
        System.out.println("Customer Number: " + customerNumber);
 
        System.out.println("Storing customer data and order information...");
 
        input.close();
        
    }
}